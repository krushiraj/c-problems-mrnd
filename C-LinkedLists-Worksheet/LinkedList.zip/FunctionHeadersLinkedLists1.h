void sll_012_sort(struct node **);
struct node * numberToLinkedList(int);
struct node * removeEveryKthNode(struct node *, int);
struct node * sortLinkedList(struct node *head);
int convert_sll_2digit_to_int(struct node *head);