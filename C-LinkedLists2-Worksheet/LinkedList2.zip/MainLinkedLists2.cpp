/*

Use MainLinkedLists2 File for testing any other function in other Cpp files of the Strings Project.

DO NOT write main function in any other File or else your Build Fails.

Objectives of LinkedLists2 Lesson:

->Merging two Linked Lists
->Reversing a LinkedList
->Inserting at a specific index

*/
#include <stdio.h>
#include "FunctionHeadersLinkedLists2.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int main(){

	//Test InsertAtEveryKthNode

	//Test LinkedListMedian

	//Test merge2 LinkedLists

	//Test reverse LinkedList

	return 0;
}