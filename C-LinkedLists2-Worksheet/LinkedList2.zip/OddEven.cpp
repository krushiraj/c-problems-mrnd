/*
Given an SLL which has a modified version of node called oddevennode .
Each oddevennode will have a next pointer and a random pointer ,The next will point to the next oddevennode
in the SLL and random will point to NULL initially.

You need to modify the SLL random pointers in such a way that ,All odd numbers in the list
are connected by random pointers in the same order in which they are in SLL and the same for even numbers.

Ex : SLL is : 1-2-3-4-5-6 
Here 1->next will point to 2 ,2->next to 3 and so on till 6->next is NULL .All 1-6 nodes have random set to
NULL initially .Now you need to modify random pointers in such a way that First Odd number in List random will
point to second odd number in the list and so on .

so 1->random should point to 3 .3->random should point to 5 .5->random to NULL (As 5 is the last Oddnumber)
and 2->random should point to 4 ,4->random should point to 6 .6->random to NULL .(As 6 is last even number)

Return an Array consisting of two numbers [Oddcount,Evencount] or NULL for invalid Inputs

Ex 2 : 50->4->3->7->10->99->17
O.P : SLL randoms should be modified as .
50->4->10 . [Even numbers if transversed through Randoms from 50]
3->7->99->17. [Odd numbers if transversed through Randoms from 3]
The function SHOULD RETURN [4,3]  . Oddnumbers and Even numbers count array .

Note : The Order of Randoms Pointers should be in the same order they are in the original SLL .so if 33 has 
arrived before 5 in the SLL .33->random should be 5 but not in reverse .And it should also be continous ,Like 
if  there is only 1 odd node 71 any where between 33 and 5 ,33->random should point to 71 and 71->random should
point to 5.
The type if node is oddevennode ,and not Node .
*/
#include <stdlib.h>
#include <stdio.h>

struct oddevennode{
	int data;
	struct oddevennode * next;
	struct oddevennode * random;

};
struct oddevennode *heado, *heade;
int * oddeven_sll(struct oddevennode *head){
	if (head == NULL)
	{
		return NULL;
	}
	int counto = 0, counte = 0;
	struct oddevennode *temp = (oddevennode *)malloc(sizeof(struct oddevennode));
	struct oddevennode *temp1 = (oddevennode *)malloc(sizeof(struct oddevennode));
	struct oddevennode *temp2 = (oddevennode *)malloc(sizeof(struct oddevennode));
	temp = head;
	temp1 = head;
	temp2 = head;
	while (temp->next != NULL)
	{
		if (temp->data % 2 != 0)
		{
			temp1 = temp;
			counto++;
			break;
		}
		temp = temp->next;
	}
	if (counto == 0)
	{
		//temp = temp->next;
		if (temp->data % 2 != 0)
		{
			temp1 = temp;
			counto++;
			if (temp1->next == NULL)
			{
				goto F;
			}
		}
	}
	temp = head;
	while (temp->next != NULL)
	{
		if (temp->data % 2 == 0)
		{
			temp2 = temp;
			counte++;
			break;
		}
		temp = temp->next;
	}
	if (counte == 0)
	{
		//temp = temp->next;
		if (temp->data % 2 == 0)
		{
			temp1 = temp;
			counte++;
		}
		if (temp2->next == NULL)
		{
			goto F;
		}
	}
	temp = temp1->next;
	if (temp1->next != NULL)
	{
		while (temp->next != NULL&&counto > 0)
		{
			if (temp->data % 2 != 0)
			{
				temp1->random = temp;
				temp1 = temp1->random;
				counto++;
			}
			temp = temp->next;
		}
	}
	//temp = temp->next;
	if (temp->data % 2 != 0)
	{
		temp1->random = temp;
		temp1 = temp1->random;
		counto++;
	}
	temp = temp2->next;
	if (temp2->next != NULL)
	{
		while (temp->next != NULL&&counte > 0)
		{
			if (temp->data % 2 == 0)
			{
				temp2->random = temp;
				temp2 = temp2->random;
				counte++;
			}
			temp = temp->next;
		}
	}
	//temp = temp->next;
	if (temp->data % 2 == 0)
	{
		temp2->random = temp;
		temp2 = temp1->random;
		counte++;
	}
F:	int *r;
	r = (int *)malloc(sizeof(int) * 2);
	*r = counto;
	*(r + 1) = counte;
	return r;
}
	/*struct oddevennode *temp1 = (oddevennode *)malloc(sizeof(struct oddevennode));
	struct oddevennode *temp2 = (oddevennode *)malloc(sizeof(struct oddevennode));
	temp = head;
	int counto = 0, counte = 0;
	heado = NULL;
	heade = NULL;
	while (temp->next != NULL)
	{
		if (head == temp)
		{
			if (temp->data % 2 == 1)
			{
				heado = temp;
				counto++;
			}
			else
			{
				heade = temp;
				counte++;
			}
		}
		if (head != temp)
		{
			if (temp->data % 2 == 1)
			{
				if (heado == NULL)
				{
					heado = temp;
					temp1 = heado;
					counto++;
				}
				else
				{
					temp1->random = temp;
					temp1 = temp1->random;
					counto++;
				}
			}
			else
			{
				if (heade == NULL)
				{
					heade = temp;
					temp2 = heade;
					counto++;
				}
				else
				{
					temp2->random = temp;
					temp2 = temp2->random;
					counte++;
				}
			}
		}
		temp = temp->next;
	}
	temp = temp->next;
	if (temp->data % 2 == 1)
	{
		temp1->random = temp;
		temp1 = temp1->random;
		counto++;
	}
	else
	{
		temp2->random = temp;
		temp2 = temp2->random;
		counte++;
	}
	int *r;
	r = (int *)malloc(sizeof(int) * 2);
	*r = counto;
	*(r + 1) = counte;
	return r;*/
